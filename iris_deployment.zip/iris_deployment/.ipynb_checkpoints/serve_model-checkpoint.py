from flask import Flask, request, jsonify
import joblib

app = Flask(__name__)

# Load model correctly using joblib
model = joblib.load("models/iris_model.pkl")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()
        print("Received data:", data)
        features = data.get("features")
        if features is None:
            return jsonify({"error": "Missing 'features' in request"}), 400
        prediction = model.predict([features])
        return jsonify({"prediction": prediction.tolist()})
    except Exception as e:
        print("Error during prediction:", str(e))
        return jsonify({"error": str(e)}), 500
