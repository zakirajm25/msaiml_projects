from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
import joblib
import os

# Load and train
iris = load_iris()
X, y = iris.data, iris.target
clf = RandomForestClassifier()
clf.fit(X, y)

# Ensure models folder exists
os.makedirs("models", exist_ok=True)

# Save model
joblib.dump(clf, "../models/iris_model.pkl")
print("✅ Model saved successfully in msaiml environment.")
